
    ███████╗████████╗ █████╗ ███████╗████████╗███████╗███████╗███████╗
    ██╔════╝╚══██╔══╝██╔══██╗██╔════╝╚══██╔══╝██╔════╝██╔════╝██╔════╝
    █████╗     ██║   ███████║███████╗   ██║   █████╗  █████╗  █████╗
    ██╔══╝     ██║   ██╔══██║╚════██╗   ██║   ██╔══╝  ██╔══╝  ██╔══╝
    ███████╗   ██║   ██║  ██║███████║   ██║   ███████╗███████╗███████╗
    ╚══════╝   ╚═╝   ╚═╝  ╚═╝╚══════╝   ╚═╝   ╚══════╝╚══════╝╚══════╝

    
ETASTEEE is a fun, experimental repository where creative coding meets a bruteforcer, educational environment. The project is designed to be a Roblox password bruteforcer, complete with colored outputs, ASCII art, and a retro, cinematic vibe inspired by classic hacker movies. This repository is purely for educational purposes hacking or unauthorized access is performed.

Features
Simulated Brute-Force Engine: Mimics a high-speed terminal attack with a visual display of password attempts represented by asterisks.

Customizable UI: Terminal interface with colorful menus and retro ASCII art that gives an authentic hacker look.

Discord Integration: Automatically sends the “cracked” password to a Discord webhook for display, adding an extra layer of interactivity.

Educational & Fun: Perfect for learning about Python scripting, terminal effects, and simulated cybersecurity—without any malicious intent.

Disclaimer
This project is intended solely for fun, educational purposes, and demonstration of coding techniques. It is not meant to be used for unauthorized access, hacking, or any illegal activities. Use responsibly and enjoy the creative coding experience!

All rights reserved!
